# Interactive 3D Plot
# Version 1.0
#   
# Displays three measures in an interactive 3D Plot. The user can change the viewpoint/angle with the mouse.
# 
# Prerequisites:
# - R library rgl must be installed.
# 
# Author: Andreas Forster
# http://scn.sap.com/people/andreas.forster
my3dplot <- function(mydata, strColNameX, strColNameY, strColNameZ, strColNameColor, strColLabel)
{
# Load required library
library(rgl)

tryCatch(
  {
  # Plot the chart.
  plot3d(mydata[, strColNameX],mydata[, strColNameY],mydata[, strColNameZ], xlab=strColNameX, ylab=strColNameY, zlab=strColNameZ, col=mydata[, strColNameColor], size=1, type='s')

  # Apply the data labels.
  with(mydata,text3d(mydata[, strColNameX],mydata[, strColNameY],mydata[, strColNameZ], mydata[, strColLabel]))

  # Keep the chart active to prevent the function from terminating.
  # This is needed for the integration with SAP Predictive Analysis.
  play3d( par3dinterp( zoom = c(1,1) ), duration=Inf)  
  },
error=function(e) {})   

## Return the input data without any modifications.
return(list(out=mydata))
}