# Add Missing Dates
# Version 1.0
#   
# Add missing dates to a daily time series. If desired, approximate missing values for measures.
# 
# Prerequisites:
# - R library zoo must be installed.
# - The first column must hold the date stamp as String value.
# - All remaining columns must be numerical values that can be approximated.
# 
# Author: Andreas Forster
# http://scn.sap.com/people/andreas.forster
myaddmissingdates <- function (myData, myDateFormat, myStrBolApproximate)
{
library(zoo)

# Create time series of existing dates
myDaySeries <- zoo(myData[,-1], as.Date(myData[,1], myDateFormat))

# Add the missing dates  
myFullDaySeries <- merge(myDaySeries, zoo(,seq(start(myDaySeries),end(myDaySeries),by="day")), all=TRUE)

# Approximate the missing measures if requested
  if(myStrBolApproximate == "True")
  {
    myFullDaySeries <- na.approx(myFullDaySeries)
  }

# Put new data frame togehter in the format of the input data.
myFormattedDate <- as.character(index(myFullDaySeries), myDateFormat)
myOutput <- cbind(myFormattedDate, data.frame(myFullDaySeries))
colnames(myOutput)[1] <- colnames(myData)[1]

# Return data
return(list(out=myOutput))
}