# Normal Distribution Test
# Version 1.0
#
# Test whether a numerical variable is normally distributed.
#
# Prerequisites:
#  - R libraries e1071, gplots, nortest and stats must be installed.
#
# Author: Andreas Forster
# http://scn.sap.com/people/andreas.forster
myNormalDistribution <- function (myData, myVariableColumnStr) 
{
  ## Test for normal distribution
  require(e1071)
  library(gplots)
  require(nortest)
  require(stats)
  
  ## set colors for plots
  colorSAPOrange <- rgb(240,171,0,max=255)  
  colorSAPMediumBlue2 <- rgb(15,70,167,max=255)
  
  ## Acquire the column by name. Only continue if the column is not a factor
  x <- myData[,myVariableColumnStr]
  if (class(x) == "factor" || sum(!is.na(as.numeric(myData[,myVariableColumnStr]))) < 2)
  {
    par(mfrow=c(1,1))
    textplot("Please select a numerical column with at least 2 values!")   
  }else 
  {
    ## Remove non-numeric information from variable
    mytotalcount <- length(x)
    mynacount <- sum(is.na(x))
    x <- as.numeric(myData[,myVariableColumnStr])
    x <- x[!is.na(x)] 
    
    ## Split screen    
    layout(mat=rbind(c(1,2),c(3,2)))
    
    ## QQ-Plot
    qqnorm(x,pch=19)
    qqline(x, col=colorSAPOrange, lwd=3)  
    
    ## Calculations
    mycount <- length(x)
    mymean <- mean(x)
    mymedian <- median(x)
    myvar <- var(x)
    mysd <- sd(x)
    mykurtosis <- kurtosis(x)
    myskewness <- skewness(x)  
    
    ## Anderson-Darling 
    myad <- try(capture.output(ad.test(x)))    
    if ( class(myad) == 'try-error' ) {      
      myad <- 'Not Available'}  
    else{myad <- sub(", ", "\n ", myad[5])}
    
    ## Shapiro-Wilk
    myshapiro <- try(capture.output(shapiro.test(x)))    
    if ( class(myshapiro) == 'try-error' ) {      
      myshapiro <- 'Not Available'}  
    else{myshapiro <- sub(", ", "\n ", myshapiro[5])}
    
    ## Lilliefors
    mylillie <- try(capture.output(lillie.test(x)))    
    if ( class(mylillie) == 'try-error' ) {      
      mylillie <- 'Not Available'}  
    else{mylillie <- sub(", ", "\n ", mylillie[5])}
    
    ## Plot the textual information
    textplot(paste(
      "Variable Statistics for:\n", myVariableColumnStr,
      "\n\nCount Cells total:\n", mytotalcount,
      "\n\nCount Cells used:\n", mycount,
      "\n\nCount Cells not used (nulls):\n", mynacount,
      "\n\nMean:\n",round(mymean,2),
      "\n\nMedian:\n", round(mymedian, 2),
      "\n\nVariance:\n",round(myvar,2),
      "\n\nStandard Deviation:\n",round(mysd,2),
      "\n\nKurtosis:\n",round(mykurtosis, digits=2),
      "\n\nSkewness:\n", round(myskewness, digits=2),                
      "\n\nAnderson-Darling:\n", myad,
      "\n\nShapiro-Wilk:\n", sub(", ", "\n ", myshapiro),
      "\n\nLilliefors:\n", sub(", ", "\n ", mylillie)))
    
      ## Plot Density
      plot(density(x), main="Density Plot")
      abline(v=mymean, lty=1,col=colorSAPMediumBlue2)
      abline(v=mymedian, lty=2,col=colorSAPOrange)
      legend("topright", legend = c("Mean", "Median"),lty = c(1,2), col=c(colorSAPMediumBlue2, colorSAPOrange),cex=0.7)
  }
  return(list(out=myData)) 
}